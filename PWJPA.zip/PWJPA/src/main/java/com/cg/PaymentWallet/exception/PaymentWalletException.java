package com.cg.PaymentWallet.exception;

public class PaymentWalletException extends Exception{
public PaymentWalletException()
{
	super();
}
public PaymentWalletException(String msg)
{
	super(msg);
}
}
